# Sugarcane Maturity Prediction — Expo Demo

This Streamlit app records sample readings and displays a transparent rule-based maturity estimate.

## Deploy/update
Upload these files to the root of your GitHub repository. Choose branch `main` and main file `app.py` in Streamlit Community Cloud.

## Local run
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Important
The demo checks whether entered Brix and crop age meet adjustable thresholds. These are demonstration settings only, not universal agronomic thresholds. Confirm locally and validate against real samples before making harvest recommendations. This version does not claim to use a trained ML model.
