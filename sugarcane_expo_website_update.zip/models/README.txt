No trained model included. Train only after verified labeled data is collected.
