import os
from datetime import datetime
import pandas as pd
import streamlit as st

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(ROOT, "data")
DATA_FILE = os.path.join(DATA_DIR, "sugarcane_readings.csv")
os.makedirs(DATA_DIR, exist_ok=True)

COLUMNS = ["timestamp", "temperature_c", "humidity_percent", "soil_moisture_percent",
           "brix", "crop_age_months", "variety", "maturity_result", "notes"]
if not os.path.exists(DATA_FILE):
    pd.DataFrame(columns=COLUMNS).to_csv(DATA_FILE, index=False)

st.set_page_config(page_title="Sugarcane Maturity Prediction", page_icon="🌱", layout="wide")
st.title("🌱 Sugarcane Maturity Prediction Device")
st.write("A farmer-friendly prototype to record crop readings and demonstrate maturity decision support.")
st.warning("EXPO DEMO: The maturity result below uses a simple adjustable rule, not a trained or scientifically validated ML model. Confirm thresholds with local agricultural experts and field testing.")

dashboard, predict, dataset, about = st.tabs(["Dashboard", "Check Maturity", "Dataset", "How it works"])
df = pd.read_csv(DATA_FILE)

with dashboard:
    st.subheader("Field Monitoring Dashboard")
    x, y, z = st.columns(3)
    x.metric("Saved samples", len(df))
    x.metric("Latest temperature", f"{df['temperature_c'].dropna().iloc[-1]:.1f} °C" if len(df) and df["temperature_c"].notna().any() else "—")
    y.metric("Latest humidity", f"{df['humidity_percent'].dropna().iloc[-1]:.1f} %" if len(df) and df["humidity_percent"].notna().any() else "—")
    z.metric("Latest Brix", f"{df['brix'].dropna().iloc[-1]:.1f}" if len(df) and df["brix"].notna().any() else "—")
    if len(df):
        st.dataframe(df.tail(10), use_container_width=True)
    else:
        st.info("No samples saved yet. Open Check Maturity to enter a sample.")

with predict:
    st.subheader("Enter sugarcane sample details")
    st.caption("For tomorrow's demonstration, this gives a transparent rule-based estimate. Use real readings when possible.")
    with st.form("predict_form"):
        c1, c2 = st.columns(2)
        with c1:
            brix = st.number_input("Brix reading (refractometer)", min_value=0.0, max_value=40.0, value=16.0, step=0.5)
            age = st.number_input("Crop age (months)", min_value=0.0, max_value=30.0, value=10.0, step=0.5)
            variety = st.text_input("Sugarcane variety (optional)", placeholder="Enter variety if known")
        with c2:
            temp = st.number_input("Temperature (°C)", min_value=-10.0, max_value=70.0, value=28.0, step=0.5)
            humidity = st.number_input("Humidity (%)", min_value=0.0, max_value=100.0, value=60.0, step=1.0)
            soil = st.number_input("Soil moisture (%)", min_value=0.0, max_value=100.0, value=40.0, step=1.0)
        st.markdown("**Demo thresholds**")
        t1, t2 = st.columns(2)
        with t1:
            brix_threshold = st.number_input("Brix threshold (demo setting)", min_value=0.0, max_value=40.0, value=18.0, step=0.5)
        with t2:
            age_threshold = st.number_input("Crop age threshold in months (demo setting)", min_value=0.0, max_value=30.0, value=10.0, step=0.5)
        notes = st.text_input("Sample location / notes (optional)")
        save = st.form_submit_button("Check maturity and save sample", type="primary")

    if save:
        if brix >= brix_threshold and age >= age_threshold:
            result = "LIKELY MATURE"
            detail = "Both entered Brix and crop age meet the demo thresholds."
        else:
            result = "LIKELY IMMATURE / NEEDS MORE CHECKING"
            detail = "At least one entered value is below the demo threshold."
        st.session_state["last_result"] = (result, detail, brix, age, brix_threshold, age_threshold)
        row = {"timestamp": datetime.now().isoformat(timespec="seconds"),
               "temperature_c": temp, "humidity_percent": humidity, "soil_moisture_percent": soil,
               "brix": brix, "crop_age_months": age, "variety": variety.strip(),
               "maturity_result": result, "notes": notes.strip()}
        pd.concat([df, pd.DataFrame([row])], ignore_index=True).to_csv(DATA_FILE, index=False)
        st.rerun()

    if "last_result" in st.session_state:
        result, detail, val_brix, val_age, bt, at = st.session_state["last_result"]
        st.divider()
        st.subheader("Maturity assessment")
        if result == "LIKELY MATURE":
            st.success("🌾 " + result)
        else:
            st.warning("🌱 " + result)
        st.write(detail)
        st.write(f"Entered Brix: **{val_brix:.1f}** (demo threshold: {bt:.1f})")
        st.write(f"Crop age: **{val_age:.1f} months** (demo threshold: {at:.1f} months)")
        st.caption("This is a rule-based expo demonstration, not a validated agricultural recommendation. Brix and age thresholds vary by variety, location, and growing conditions.")

with dataset:
    st.subheader("Saved samples")
    st.dataframe(pd.read_csv(DATA_FILE), use_container_width=True)
    st.download_button("Download dataset CSV", data=pd.read_csv(DATA_FILE).to_csv(index=False).encode("utf-8"),
                       file_name="sugarcane_readings.csv", mime="text/csv")

with about:
    st.subheader("Project workflow")
    st.markdown("""
1. Measure temperature and humidity using the DHT11 sensor.
2. Measure soil moisture using the soil moisture sensor.
3. Measure Brix with a handheld refractometer and enter the reading.
4. Enter crop age and optional variety information.
5. The app compares Brix and age with adjustable demo thresholds.
6. The app saves each sample to a CSV dataset.

**Important:** The current expo version uses transparent rule-based logic. A trained Random Forest model should only be presented as producing predictions after collecting enough real, independently verified maturity labels, training it, and evaluating it.
""")
